# NexusAI

Sua IA pessoal com Modo Normal e Modo Estudante.

## Como hospedar

1. Crie uma conta em github.com
2. Crie um repositório chamado `nexusai`
3. Faça upload de todos os arquivos desta pasta
4. Acesse vercel.com → entre com GitHub → importe o repositório
5. Clique em Deploy — pronto!

## Tecnologias
- React 18
- API Claude (Anthropic)
- Vercel (hospedagem)
