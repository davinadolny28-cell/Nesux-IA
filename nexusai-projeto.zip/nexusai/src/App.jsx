import { useState, useRef, useEffect } from "react";

const uid = () => Math.random().toString(36).slice(2, 9);

const SUGGESTIONS = {
  normal: ["Resuma um texto para mim","Me ajude a escrever um e-mail","Explique um conceito difícil","Crie ideias para meu negócio"],
  student: ["Explique como se eu tivesse 10 anos","Crie um quiz sobre fotossíntese","Faça um resumo para estudar","Monte um plano de estudos"],
};

const SYSTEMS = {
  normal: "Você é uma IA assistente profissional, inteligente e prestativa. Responda sempre em português de forma clara e objetiva.",
  student: `Você é um tutor educacional especializado. Sempre responda em português com linguagem simples, exemplos do dia a dia e analogias criativas.

REGRA IMPORTANTE: Quando o usuário pedir um quiz ou perguntas, responda SOMENTE com um JSON puro, sem nenhum texto antes ou depois, sem markdown, sem blocos de código. Apenas o JSON assim:
{"type":"quiz","question":"Pergunta aqui?","options":["Opção A","Opção B","Opção C","Opção D"],"answer":0}

O campo "answer" é o índice (0, 1, 2 ou 3) da opção correta.
Para qualquer outro pedido que não seja quiz, responda normalmente em texto.`,
};

function parseQuiz(text) {
  try {
    const clean = text.trim().replace(/```json|```/g, "").trim();
    const obj = JSON.parse(clean);
    if (obj.type === "quiz" && obj.question && Array.isArray(obj.options) && typeof obj.answer === "number") return obj;
  } catch {}
  return null;
}

/* ══════════════════════════════════════════
   QUIZ CARD
══════════════════════════════════════════ */
function QuizCard({ quiz, onNext }) {
  const [selected, setSelected] = useState(null);
  const answered = selected !== null;
  const correct = selected === quiz.answer;
  const labels = ["A","B","C","D"];
  return (
    <div style={QS.card}>
      <span style={QS.badge}>📝 QUIZ</span>
      <p className="quiz-question" style={QS.question}>{quiz.question}</p>
      <div style={QS.options}>
        {quiz.options.map((opt, i) => {
          const isRight = answered && i === quiz.answer;
          const isWrong = answered && i === selected && i !== quiz.answer;
          return (
            <button key={i} style={{ ...QS.option,
              background: !answered ? "rgba(255,255,255,0.04)" : isRight ? "rgba(34,197,94,0.12)" : isWrong ? "rgba(239,68,68,0.1)" : "rgba(255,255,255,0.03)",
              border: !answered ? "1px solid rgba(255,255,255,0.1)" : isRight ? "1px solid rgba(34,197,94,0.45)" : isWrong ? "1px solid rgba(239,68,68,0.4)" : "1px solid rgba(255,255,255,0.06)",
              cursor: answered ? "default" : "pointer",
              opacity: answered && !isRight && !isWrong ? 0.5 : 1,
            }} className={!answered ? "quiz-opt" : ""} onClick={() => !answered && setSelected(i)} disabled={answered}>
              <span className="quiz-letter" style={{ ...QS.letter,
                background: !answered ? "rgba(255,255,255,0.08)" : isRight ? "rgba(34,197,94,0.25)" : isWrong ? "rgba(239,68,68,0.2)" : "rgba(255,255,255,0.05)",
                color: !answered ? "#aaa" : isRight ? "#4ade80" : isWrong ? "#fca5a5" : "#555",
              }}>{labels[i]}</span>
              <span style={{ color: !answered ? "#ccc8e0" : isRight ? "#86efac" : isWrong ? "#fca5a5" : "#666", fontSize: "14px", flex: 1, textAlign: "left" }}>{opt}</span>
              {answered && isRight && <span>✅</span>}
              {answered && isWrong && <span>❌</span>}
            </button>
          );
        })}
      </div>
      {answered && (
        <div style={{ ...QS.feedback, background: correct ? "rgba(34,197,94,0.08)" : "rgba(239,68,68,0.08)", border: `1px solid ${correct ? "rgba(34,197,94,0.2)" : "rgba(239,68,68,0.2)"}` }}>
          <span style={{ fontSize: "20px" }}>{correct ? "🎉" : "💡"}</span>
          <div>
            <div style={{ fontWeight: 700, color: correct ? "#4ade80" : "#fca5a5", fontSize: "14px" }}>{correct ? "Correto! Muito bem!" : "Não foi dessa vez..."}</div>
            {!correct && <div style={{ fontSize: "13px", color: "#86efac", marginTop: "2px" }}>Resposta certa: <strong>{quiz.options[quiz.answer]}</strong></div>}
          </div>
        </div>
      )}
      {answered && <button style={QS.nextBtn} className="quiz-next" onClick={onNext}>Próxima pergunta →</button>}
    </div>
  );
}

const QS = {
  card: { background: "rgba(17,17,30,0.9)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: "18px", padding: "22px", display: "flex", flexDirection: "column", gap: "16px", maxWidth: "500px", width: "100%" },
  badge: { fontSize: "11px", fontWeight: 800, color: "#4ade80", letterSpacing: "1px", background: "rgba(34,197,94,0.12)", border: "1px solid rgba(34,197,94,0.2)", borderRadius: "20px", padding: "3px 10px", alignSelf: "flex-start" },
  question: { fontSize: "16px", fontWeight: 700, color: "#f0fff4", lineHeight: 1.55, margin: 0 },
  options: { display: "flex", flexDirection: "column", gap: "9px" },
  option: { display: "flex", alignItems: "center", gap: "12px", padding: "13px 15px", borderRadius: "12px", fontFamily: "inherit", transition: "all 0.15s" },
  letter: { width: 28, height: 28, borderRadius: "8px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "13px", fontWeight: 800, flexShrink: 0, transition: "all 0.15s" },
  feedback: { display: "flex", alignItems: "flex-start", gap: "12px", padding: "14px 16px", borderRadius: "12px" },
  nextBtn: { background: "linear-gradient(135deg,#16a34a,#15803d)", border: "none", borderRadius: "10px", padding: "11px 20px", color: "#fff", fontSize: "14px", fontWeight: 700, cursor: "pointer", fontFamily: "inherit", alignSelf: "flex-start" },
};

/* ══════════════════════════════════════════
   MESSAGE
══════════════════════════════════════════ */
function Message({ m, isStudent, onQuizNext }) {
  const quiz = isStudent && m.role === "assistant" ? parseQuiz(m.content) : null;
  if (quiz) return (
    <div style={{ display: "flex", gap: "10px", alignItems: "flex-start" }}>
      <div style={{ ...S.avatar, background: "rgba(34,197,94,0.12)", border: "1px solid rgba(34,197,94,0.25)", flexShrink: 0, marginTop: 2 }}>
        <LogoIcon size={13} color="#22c55e" />
      </div>
      <QuizCard quiz={quiz} onNext={onQuizNext} />
    </div>
  );
  return (
    <div style={S.msgRow(m.role)}>
      {m.role === "assistant" && (
        <div style={{ ...S.avatar, background: isStudent ? "rgba(34,197,94,0.12)" : "rgba(124,58,237,0.15)", border: `1px solid ${isStudent ? "rgba(34,197,94,0.25)" : "rgba(167,139,250,0.2)"}` }}>
          <LogoIcon size={13} color={isStudent ? "#22c55e" : "#7c3aed"} />
        </div>
      )}
      <div className={m.role === "user" ? "bubble-user" : "bubble-ai"} style={{ ...S.bubble(m.role), background: m.role === "user" ? (isStudent ? "linear-gradient(135deg,#16a34a,#15803d)" : "linear-gradient(135deg,#6d28d9,#4338ca)") : "rgba(255,255,255,0.05)" }}>
        {m.content}
        {m.role === "assistant" && m.content === "" && (
          <>
            <span className="dot-1" style={{ ...S.dot, background: isStudent ? "#22c55e" : "#7c3aed" }} />
            <span className="dot-2" style={{ ...S.dot, background: isStudent ? "#22c55e" : "#7c3aed" }} />
            <span className="dot-3" style={{ ...S.dot, background: isStudent ? "#22c55e" : "#7c3aed" }} />
          </>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   ROOT
══════════════════════════════════════════ */
export default function App() {
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState("login");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [view, setView] = useState("chat");
  const [mode, setMode] = useState("normal");
  const [conversations, setConversations] = useState([{ id: uid(), title: "Nova conversa", messages: [], mode: "normal" }]);
  const [activeId, setActiveId] = useState(conversations[0].id);
  const [loading, setLoading] = useState(false);
  const [input, setInput] = useState("");
  const textareaRef = useRef(null);
  const bottomRef = useRef(null);
  const activeIdRef = useRef(activeId);
  activeIdRef.current = activeId;

  const active = conversations.find((c) => c.id === activeId);
  const isStudent = mode === "student";

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [active?.messages, loading]);

  if (!user) return <AuthScreen mode={authMode} setMode={setAuthMode} onAuth={setUser} />;

  const newChat = () => {
    const c = { id: uid(), title: "Nova conversa", messages: [], mode };
    setConversations((prev) => [c, ...prev]);
    setActiveId(c.id);
    setSidebarOpen(false);
    setView("chat");
  };

  const setTitle = (id, firstMsg) => {
    setConversations((prev) => prev.map((c) => c.id !== id ? c : { ...c, title: firstMsg.slice(0, 32) + (firstMsg.length > 32 ? "…" : "") }));
  };

  const autoResize = () => {
    const ta = textareaRef.current;
    if (!ta) return;
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 140) + "px";
  };

  const send = async (text) => {
    const msg = (text || input).trim();
    if (!msg || loading) return;
    const convId = activeIdRef.current;
    const history = active?.messages || [];
    const cleanHistory = history.map((m) => {
      const q = isStudent && m.role === "assistant" ? parseQuiz(m.content) : null;
      return q ? { role: m.role, content: `[Quiz: ${q.question}]` } : m;
    });
    const userMsg = { role: "user", content: msg };
    const apiMsgs = [...cleanHistory, userMsg];

    // Add user message + empty assistant placeholder
    setConversations((prev) => prev.map((c) => {
      if (c.id !== convId) return c;
      const wasEmpty = c.messages.length === 0;
      return { ...c, messages: [...c.messages, userMsg, { role: "assistant", content: "" }], title: wasEmpty ? msg.slice(0, 32) + (msg.length > 32 ? "…" : "") : c.title };
    }));

    setInput("");
    if (textareaRef.current) textareaRef.current.style.height = "52px";
    setLoading(true);

    const appendToken = (token) => {
      setConversations((prev) => prev.map((c) => {
        if (c.id !== convId) return c;
        const msgs = [...c.messages];
        msgs[msgs.length - 1] = { role: "assistant", content: msgs[msgs.length - 1].content + token };
        return { ...c, messages: msgs };
      }));
    };

    const setFinalMsg = (content) => {
      setConversations((prev) => prev.map((c) => {
        if (c.id !== convId) return c;
        const msgs = [...c.messages];
        msgs[msgs.length - 1] = { role: "assistant", content };
        return { ...c, messages: msgs };
      }));
    };

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-6",
          max_tokens: 1000,
          stream: true,
          system: SYSTEMS[mode],
          messages: apiMsgs,
        }),
      });

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop();
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          try {
            const json = JSON.parse(line.slice(6));
            if (json.type === "content_block_delta" && json.delta?.text) {
              appendToken(json.delta.text);
            }
          } catch {}
        }
      }
    } catch {
      setFinalMsg("Erro de conexão. Tente novamente.");
    } finally {
      setLoading(false);
    }
  };

  const handleQuizNext = () => send("Crie mais uma pergunta de quiz sobre o mesmo tema");
  const started = (active?.messages || []).length > 0;

  return (
    <div style={S.root}>
      <style>{CSS}</style>
      {sidebarOpen && <div style={S.overlay} onClick={() => setSidebarOpen(false)} />}

      {/* ── Sidebar ── */}
      <aside style={{ ...S.sidebar, transform: sidebarOpen ? "translateX(0)" : "translateX(-100%)" }}>
        <div style={S.sidebarTop}>
          <div style={S.logoWrap}><LogoIcon color={isStudent ? "#22c55e" : "#7c3aed"} /><span style={S.logoText} className="logo-text">NexusAI</span></div>
          <button style={S.iconBtn} onClick={() => setSidebarOpen(false)}><XIcon /></button>
        </div>
        <div style={S.modeToggleWrap}>
          <button style={S.modeBtn(mode === "normal", false)} className="mode-btn" onClick={() => setMode("normal")}>⚡ Normal</button>
          <button style={S.modeBtn(mode === "student", true)} className="mode-btn-s" onClick={() => setMode("student")}>🎓 Estudante</button>
        </div>
        <button style={{ ...S.newChatBtn, background: isStudent ? "linear-gradient(135deg,#16a34a,#15803d)" : "linear-gradient(135deg,#7c3aed,#4338ca)" }} className="new-chat-btn" onClick={newChat}>+ Nova conversa</button>
        <div style={S.sidebarSection}>Conversas</div>
        <div style={S.convList}>
          {conversations.map((c) => (
            <button key={c.id} style={S.convItem(c.id === activeId)} className="conv-item"
              onClick={() => { setActiveId(c.id); setMode(c.mode || "normal"); setView("chat"); setSidebarOpen(false); }}>
              <span style={{ fontSize: "11px" }}>{c.mode === "student" ? "🎓" : "⚡"}</span>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.title}</span>
            </button>
          ))}
        </div>
        <div style={S.sidebarBottom}>
          <button style={S.settingsBtn(view === "settings")} className="settings-btn" onClick={() => { setView("settings"); setSidebarOpen(false); }}>
            <GearIcon color={view === "settings" ? "#a78bfa" : "#666"} /> Configurações
          </button>
          <div style={S.userChip}>
            <div style={{ ...S.userAvatar, background: isStudent ? "linear-gradient(135deg,#16a34a,#15803d)" : "linear-gradient(135deg,#7c3aed,#2563eb)" }}>{user.name[0].toUpperCase()}</div>
            <div><div style={{ fontSize: "13px", fontWeight: 600, color: "#ddd8f0" }}>{user.name}</div><div style={{ fontSize: "11px", color: "#555" }}>{user.email}</div></div>
            <button style={{ ...S.iconBtn, marginLeft: "auto" }} onClick={() => setUser(null)}><LogoutIcon /></button>
          </div>
        </div>
      </aside>

      {/* ── Main ── */}
      <div style={S.main}>
        <header style={S.header}>
          <button style={S.hamburger} className="hamburger" onClick={() => setSidebarOpen(true)}>
            <span style={S.bar} /><span style={S.bar} /><span style={S.bar} />
          </button>
          <div style={S.logoWrap}>
            <LogoIcon color={isStudent ? "#22c55e" : "#7c3aed"} /><span style={S.logoText} className="logo-text">NexusAI</span>
            {isStudent && <span style={S.modeBadge} className="mode-badge">🎓 Estudante</span>}
          </div>
          <div style={S.headerToggle}>
            <button style={S.headerModeBtn(mode === "normal")} onClick={() => setMode("normal")}>⚡</button>
            <button style={S.headerModeBtn(mode === "student")} onClick={() => setMode("student")}>🎓</button>
          </div>
        </header>

        {view === "settings" ? (
          <SettingsView user={user} setUser={setUser} onLogout={() => setUser(null)} />
        ) : (
          <div style={S.chatArea}>
            {isStudent && !started && (
              <div style={S.studentBanner}>
                <span style={{ fontSize: "20px" }}>🎓</span>
                <div>
                  <div style={{ fontWeight: 600, color: "#86efac", fontSize: "14px" }}>Modo Estudante ativo</div>
                  <div style={{ fontSize: "13px", color: "#4ade80", opacity: 0.8 }}>Explicações simples · Exemplos práticos · Quiz interativo</div>
                </div>
              </div>
            )}
            {!started && (
              <div style={S.welcome}>
                <div style={{ ...S.glow, background: `radial-gradient(circle,${isStudent ? "rgba(34,197,94,0.12)" : "rgba(124,58,237,0.12)"} 0%,transparent 70%)` }} />
                <h1 className={isStudent ? "welcome-title-student" : "welcome-title"} style={{ ...S.welcomeTitle, background: isStudent ? "linear-gradient(135deg,#f0fff4 30%,#86efac)" : "linear-gradient(135deg,#e0d4ff 20%,#a78bfa 60%,#60a5fa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                  {isStudent ? "O que vamos aprender?" : "Como posso ajudar?"}
                </h1>
                <p style={S.welcomeSub}>{isStudent ? "Explico qualquer assunto de forma simples, com exemplos e quiz interativo." : "Sua IA pessoal para responder qualquer dúvida e criar textos."}</p>
                <div style={S.chips}>
                  {SUGGESTIONS[mode].map((s) => (
                    <button key={s} style={S.chip} className={isStudent ? "chip-s" : "chip"} onClick={() => send(s)}>{s}</button>
                  ))}
                </div>
              </div>
            )}
            {started && (
              <div style={S.messages}>
                {(active?.messages || []).map((m, i) => (
                  <Message key={i} m={m} isStudent={isStudent} onQuizNext={handleQuizNext} />
                ))}
                <div ref={bottomRef} />
              </div>
            )}
            {isStudent && started && (
              <div style={S.studentTools}>
                <button style={S.toolBtn} className="tool-btn" onClick={() => send("Crie um quiz de 1 pergunta sobre o que discutimos")}>📝 Quiz</button>
                <button style={S.toolBtn} className="tool-btn" onClick={() => send("Faça um resumo dos pontos principais")}>📋 Resumo</button>
                <button style={S.toolBtn} className="tool-btn" onClick={() => send("Explique de forma ainda mais simples")}>🔍 Simplificar</button>
                <button style={S.toolBtn} className="tool-btn" onClick={() => send("Monte um plano de estudos sobre este tema")}>📅 Plano</button>
              </div>
            )}
            <div style={S.inputWrap}>
              <div style={S.inputBox} className="input-box">
                <textarea ref={textareaRef} style={S.textarea}
                  placeholder={isStudent ? "Qual matéria ou dúvida quer explorar?" : "Escreva sua mensagem..."}
                  value={input} rows={1}
                  onChange={(e) => { setInput(e.target.value); autoResize(); }}
                  onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }}
                />
                <button style={{ ...S.sendBtn(!!input.trim() && !loading), background: !!input.trim() && !loading ? (isStudent ? "linear-gradient(135deg,#16a34a,#15803d)" : "linear-gradient(135deg,#7c3aed,#4338ca)") : "rgba(255,255,255,0.07)" }}
                  className="send-btn" onClick={() => send()} disabled={!input.trim() || loading}>
                  <SendIcon />
                </button>
              </div>
              <p style={S.hint}>Enter para enviar · Shift+Enter para nova linha</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   AUTH
══════════════════════════════════════════ */
function AuthScreen({ mode, setMode, onAuth }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const submit = () => {
    setError("");
    if (mode === "register") {
      if (!name.trim()) return setError("Informe seu nome.");
      if (!email.includes("@") || !email.includes(".")) return setError("E-mail inválido.");
      if (password.length < 6) return setError("Senha deve ter pelo menos 6 caracteres.");
      onAuth({ name: name.trim(), email: email.trim() });
    } else {
      if (!email.includes("@") || !password) return setError("Preencha e-mail e senha.");
      onAuth({ name: email.split("@")[0], email: email.trim() });
    }
  };
  return (
    <div style={A.root}><style>{CSS}</style>
      <div style={A.card}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "10px", marginBottom: "8px" }}>
          <LogoIcon /><span style={{ fontSize: "20px", fontWeight: 700, color: "#f0eeff" }}>NexusAI</span>
        </div>
        <h2 className="auth-title" style={A.title}>{mode === "login" ? "Entrar na sua conta" : "Criar conta grátis"}</h2>
        {mode === "register" && <div style={A.field}><label style={A.label}>Nome</label><input style={A.input} className="auth-input" placeholder="Seu nome" value={name} onChange={(e) => setName(e.target.value)} /></div>}
        <div style={A.field}><label style={A.label}>E-mail</label><input style={A.input} className="auth-input" type="email" placeholder="voce@email.com" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div style={A.field}><label style={A.label}>Senha</label><input style={A.input} className="auth-input" type="password" placeholder="••••••••" value={password} onChange={(e) => setPassword(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") submit(); }} /></div>
        {error && <div style={A.error}>{error}</div>}
        <button style={A.btn} className="auth-btn" onClick={submit}>{mode === "login" ? "Entrar" : "Criar conta"}</button>
        <p style={A.toggle}>{mode === "login" ? "Ainda não tem conta?" : "Já tem conta?"}{" "}<span style={A.link} onClick={() => { setMode(mode === "login" ? "register" : "login"); setError(""); }}>{mode === "login" ? "Cadastre-se" : "Entrar"}</span></p>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   SETTINGS
══════════════════════════════════════════ */
function SettingsView({ user, setUser, onLogout }) {
  const [name, setName] = useState(user.name);
  const [saved, setSaved] = useState(false);
  const save = () => { setUser({ ...user, name: name.trim() || user.name }); setSaved(true); setTimeout(() => setSaved(false), 2000); };
  return (
    <div style={SE.root}>
      <h2 style={SE.title}>Configurações</h2>
      <div style={SE.section}>
        <div style={SE.sectionTitle}>Perfil</div>
        <div style={A.field}><label style={A.label}>Nome</label><input style={A.input} className="auth-input" value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div style={A.field}><label style={A.label}>E-mail</label><input style={{ ...A.input, opacity: 0.5, cursor: "not-allowed" }} value={user.email} readOnly /></div>
        <button style={A.btn} className="auth-btn" onClick={save}>{saved ? "✓ Salvo!" : "Salvar alterações"}</button>
      </div>
      <div style={SE.section}>
        <div style={SE.sectionTitle}>Conta</div>
        <button style={SE.dangerBtn} className="danger-btn" onClick={onLogout}>Sair da conta</button>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   ICONS
══════════════════════════════════════════ */
const LogoIcon = ({ size = 16, color = "#7c3aed" }) => (
  <div style={{ width: 28, height: 28, background: `linear-gradient(135deg,${color},${color === "#22c55e" ? "#15803d" : "#2563eb"})`, borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
  </div>
);
const XIcon = () => (<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#888" strokeWidth="2" strokeLinecap="round" /></svg>);
const GearIcon = ({ color = "#666" }) => (<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3" stroke={color} strokeWidth="2" /><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" stroke={color} strokeWidth="2" /></svg>);
const LogoutIcon = () => (<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9" stroke="#666" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>);
const SendIcon = () => (<svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M22 2L11 13M22 2L15 22l-4-9-9-4 20-7z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>);

/* ══════════════════════════════════════════
   STYLES
══════════════════════════════════════════ */
const S = {
  root: { minHeight: "100vh", background: "#07070d", color: "#ddd8f0", fontFamily: "'Plus Jakarta Sans','Inter',system-ui,sans-serif", display: "flex", overflow: "hidden" },
  overlay: { position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 40, backdropFilter: "blur(2px)" },
  sidebar: { position: "fixed", top: 0, left: 0, bottom: 0, width: "270px", background: "#0e0e18", borderRight: "1px solid rgba(255,255,255,0.06)", display: "flex", flexDirection: "column", zIndex: 50, transition: "transform 0.25s cubic-bezier(.4,0,.2,1)" },
  sidebarTop: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "16px 16px 12px" },
  logoWrap: { display: "flex", alignItems: "center", gap: "10px" },
  logoText: { fontSize: "16px", fontWeight: 800, letterSpacing: "-0.3px", color: "#f0eeff" },
  modeToggleWrap: { display: "flex", gap: "6px", margin: "0 12px 8px", background: "rgba(255,255,255,0.04)", borderRadius: "10px", padding: "4px" },
  modeBtn: (active, isS) => ({ flex: 1, padding: "7px 8px", borderRadius: "7px", border: "none", cursor: "pointer", fontSize: "12px", fontWeight: 600, fontFamily: "inherit", display: "flex", alignItems: "center", justifyContent: "center", gap: "5px", transition: "all 0.15s", background: active ? (isS ? "rgba(34,197,94,0.15)" : "rgba(124,58,237,0.15)") : "transparent", color: active ? (isS ? "#4ade80" : "#a78bfa") : "#555" }),
  newChatBtn: { margin: "0 12px 8px", padding: "10px 14px", borderRadius: "10px", border: "none", color: "#fff", fontSize: "14px", fontWeight: 600, cursor: "pointer", fontFamily: "inherit" },
  sidebarSection: { fontSize: "11px", fontWeight: 600, color: "#444", letterSpacing: "0.8px", textTransform: "uppercase", padding: "12px 16px 6px" },
  convList: { flex: 1, overflowY: "auto", padding: "0 8px", display: "flex", flexDirection: "column", gap: "2px" },
  convItem: (active) => ({ display: "flex", alignItems: "center", gap: "9px", padding: "9px 10px", borderRadius: "8px", background: active ? "rgba(255,255,255,0.07)" : "transparent", border: active ? "1px solid rgba(255,255,255,0.08)" : "1px solid transparent", color: active ? "#ddd8f0" : "#666", fontSize: "13px", cursor: "pointer", textAlign: "left", fontFamily: "inherit", transition: "all 0.12s" }),
  sidebarBottom: { padding: "12px", borderTop: "1px solid rgba(255,255,255,0.06)", display: "flex", flexDirection: "column", gap: "6px" },
  settingsBtn: (active) => ({ display: "flex", alignItems: "center", gap: "9px", padding: "9px 10px", borderRadius: "8px", background: active ? "rgba(124,58,237,0.12)" : "transparent", border: "none", color: active ? "#a78bfa" : "#666", fontSize: "13px", cursor: "pointer", fontFamily: "inherit", transition: "all 0.12s" }),
  userChip: { display: "flex", alignItems: "center", gap: "10px", padding: "8px 6px", borderRadius: "8px", background: "rgba(255,255,255,0.03)" },
  userAvatar: { width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "13px", fontWeight: 700, color: "#fff", flexShrink: 0 },
  iconBtn: { background: "none", border: "none", cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", padding: "4px", borderRadius: "6px" },
  main: { flex: 1, display: "flex", flexDirection: "column", minHeight: "100vh" },
  header: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "13px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(7,7,13,0.9)", backdropFilter: "blur(10px)", position: "sticky", top: 0, zIndex: 10 },
  modeBadge: { fontSize: "11px", fontWeight: 600, background: "rgba(34,197,94,0.12)", color: "#4ade80", border: "1px solid rgba(34,197,94,0.2)", borderRadius: "20px", padding: "2px 9px" },
  headerToggle: { display: "flex", background: "rgba(255,255,255,0.05)", borderRadius: "9px", padding: "3px", gap: "3px" },
  headerModeBtn: (active) => ({ width: 32, height: 28, borderRadius: "6px", border: "none", background: active ? "rgba(255,255,255,0.1)" : "transparent", cursor: "pointer", fontSize: "14px", display: "flex", alignItems: "center", justifyContent: "center", transition: "all 0.15s" }),
  hamburger: { background: "none", border: "none", cursor: "pointer", display: "flex", flexDirection: "column", gap: "5px", padding: "4px", borderRadius: "6px" },
  bar: { display: "block", width: "22px", height: "2px", background: "#aaa", borderRadius: "2px" },
  chatArea: { flex: 1, display: "flex", flexDirection: "column", maxWidth: "720px", width: "100%", margin: "0 auto", padding: "0 16px" },
  studentBanner: { display: "flex", alignItems: "center", gap: "12px", background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.15)", borderRadius: "12px", padding: "12px 16px", margin: "16px 0 0" },
  welcome: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: "40px 0 24px", position: "relative" },
  glow: { position: "absolute", top: "40%", left: "50%", transform: "translate(-50%,-50%)", width: "300px", height: "300px", pointerEvents: "none" },
  welcomeTitle: { fontSize: "clamp(26px,5vw,40px)", fontWeight: 700, letterSpacing: "-1px", margin: "0 0 12px", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" },
  welcomeSub: { fontSize: "15px", color: "#6b6880", maxWidth: "380px", lineHeight: 1.6, margin: "0 0 32px" },
  chips: { display: "flex", flexWrap: "wrap", gap: "10px", justifyContent: "center", maxWidth: "520px" },
  chip: { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.09)", borderRadius: "24px", padding: "9px 18px", color: "#b0a8cc", fontSize: "13px", cursor: "pointer", transition: "all 0.15s", fontFamily: "inherit" },
  messages: { flex: 1, overflowY: "auto", padding: "28px 0 8px", display: "flex", flexDirection: "column", gap: "20px" },
  msgRow: (role) => ({ display: "flex", flexDirection: "row", alignItems: "flex-start", justifyContent: role === "user" ? "flex-end" : "flex-start", gap: "10px" }),
  avatar: { width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", marginTop: "2px" },
  bubble: (role) => ({ maxWidth: "78%", padding: "12px 16px", borderRadius: role === "user" ? "18px 4px 18px 18px" : "4px 18px 18px 18px", border: role === "user" ? "none" : "1px solid rgba(255,255,255,0.07)", fontSize: "15px", lineHeight: 1.65, color: role === "user" ? "#fff" : "#ccc8e0", whiteSpace: "pre-wrap", wordBreak: "break-word", display: "flex", gap: "5px", alignItems: "center", minHeight: "44px" }),
  dot: { display: "inline-block", width: 7, height: 7, borderRadius: "50%", flexShrink: 0 },
  studentTools: { display: "flex", gap: "8px", flexWrap: "wrap", padding: "8px 0" },
  toolBtn: { background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.15)", borderRadius: "20px", padding: "6px 14px", color: "#4ade80", fontSize: "12px", fontWeight: 600, cursor: "pointer", fontFamily: "inherit", transition: "all 0.15s" },
  inputWrap: { padding: "12px 0 20px", display: "flex", flexDirection: "column", gap: "8px" },
  inputBox: { display: "flex", alignItems: "flex-end", gap: "10px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "16px", padding: "8px 8px 8px 16px", transition: "border-color 0.2s" },
  textarea: { flex: 1, background: "transparent", border: "none", outline: "none", color: "#ddd8f0", fontSize: "15px", fontFamily: "inherit", resize: "none", lineHeight: 1.6, minHeight: "36px", paddingTop: "6px", paddingBottom: "6px" },
  sendBtn: (active) => ({ width: 40, height: 40, borderRadius: "10px", border: "none", color: active ? "#fff" : "#555", cursor: active ? "pointer" : "not-allowed", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.15s" }),
  hint: { fontSize: "12px", color: "#3d3a50", textAlign: "center", margin: 0 },
};

const A = {
  root: { minHeight: "100vh", background: "#07070d", display: "flex", alignItems: "center", justifyContent: "center", padding: "24px 16px", fontFamily: "'Plus Jakarta Sans','Inter',system-ui,sans-serif" },
  card: { width: "100%", maxWidth: "380px", background: "#0e0e18", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "20px", padding: "36px 32px" },
  title: { fontSize: "20px", fontWeight: 700, color: "#f0eeff", textAlign: "center", margin: "0 0 28px", letterSpacing: "-0.3px" },
  field: { display: "flex", flexDirection: "column", gap: "6px", marginBottom: "16px" },
  label: { fontSize: "12px", fontWeight: 600, color: "#666", letterSpacing: "0.4px" },
  input: { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "10px", padding: "11px 14px", color: "#ddd8f0", fontSize: "14px", outline: "none", fontFamily: "inherit" },
  btn: { width: "100%", padding: "12px", borderRadius: "11px", border: "none", background: "linear-gradient(135deg,#7c3aed,#4338ca)", color: "#fff", fontSize: "15px", fontWeight: 600, cursor: "pointer", fontFamily: "inherit", marginTop: "4px" },
  toggle: { textAlign: "center", fontSize: "13px", color: "#555", margin: "16px 0 0" },
  link: { color: "#a78bfa", cursor: "pointer", fontWeight: 600 },
  error: { background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: "8px", padding: "9px 12px", color: "#fca5a5", fontSize: "13px", marginBottom: "12px" },
};

const SE = {
  root: { flex: 1, maxWidth: "540px", width: "100%", margin: "0 auto", padding: "40px 16px", fontFamily: "inherit" },
  title: { fontSize: "22px", fontWeight: 700, color: "#f0eeff", letterSpacing: "-0.4px", marginBottom: "32px" },
  section: { background: "#0e0e18", border: "1px solid rgba(255,255,255,0.07)", borderRadius: "14px", padding: "24px", marginBottom: "16px" },
  sectionTitle: { fontSize: "12px", fontWeight: 700, color: "#555", letterSpacing: "0.8px", textTransform: "uppercase", marginBottom: "16px" },
  dangerBtn: { background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", borderRadius: "10px", padding: "10px 16px", color: "#fca5a5", fontSize: "14px", cursor: "pointer", fontFamily: "inherit" },
};

const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #07070d; font-family: 'Plus Jakarta Sans', 'Inter', system-ui, sans-serif; }

  /* ── scrollbar ── */
  ::-webkit-scrollbar { width: 3px; }
  ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }

  /* ── global font upgrade ── */
  * { font-family: 'Plus Jakarta Sans', 'Inter', system-ui, sans-serif; }

  /* ── logo text glow ── */
  .logo-text {
    font-size: 18px !important;
    font-weight: 800 !important;
    letter-spacing: -0.5px !important;
    background: linear-gradient(135deg, #e0d4ff, #a78bfa, #60a5fa) !important;
    -webkit-background-clip: text !important;
    -webkit-text-fill-color: transparent !important;
    filter: drop-shadow(0 0 12px rgba(167,139,250,0.4));
  }

  /* ── welcome title glow ── */
  .welcome-title {
    font-size: clamp(30px, 6vw, 52px) !important;
    font-weight: 800 !important;
    letter-spacing: -2px !important;
    line-height: 1.1 !important;
    filter: drop-shadow(0 0 30px rgba(167,139,250,0.25));
  }
  .welcome-title-student {
    font-size: clamp(30px, 6vw, 52px) !important;
    font-weight: 800 !important;
    letter-spacing: -2px !important;
    line-height: 1.1 !important;
    filter: drop-shadow(0 0 30px rgba(34,197,94,0.25));
  }

  /* ── bubble text ── */
  .bubble-ai {
    font-size: 15.5px !important;
    font-weight: 500 !important;
    line-height: 1.7 !important;
    color: #e2deff !important;
    letter-spacing: 0.1px;
  }
  .bubble-user {
    font-size: 15.5px !important;
    font-weight: 600 !important;
    line-height: 1.65 !important;
    letter-spacing: 0.1px;
  }

  /* ── quiz question bold ── */
  .quiz-question {
    font-size: 17px !important;
    font-weight: 800 !important;
    color: #f0fff4 !important;
    letter-spacing: -0.3px !important;
    text-shadow: 0 0 20px rgba(34,197,94,0.2);
  }

  /* ── sidebar conv title ── */
  .conv-title { font-weight: 600; font-size: 13.5px; }

  /* ── section labels ── */
  .section-label {
    font-size: 11px !important;
    font-weight: 800 !important;
    letter-spacing: 1.2px !important;
    text-transform: uppercase !important;
  }

  /* ── auth card title ── */
  .auth-title {
    font-size: 22px !important;
    font-weight: 800 !important;
    letter-spacing: -0.5px !important;
    color: #f0eeff !important;
  }

  /* ── button labels ── */
  .new-chat-btn { font-weight: 700 !important; font-size: 14px !important; letter-spacing: 0.1px; }
  .tool-btn { font-weight: 700 !important; font-size: 12.5px !important; }
  .quiz-next { font-weight: 800 !important; font-size: 14px !important; letter-spacing: 0.2px; }
  .send-btn { font-weight: 700 !important; }
  .auth-btn { font-weight: 800 !important; font-size: 15.5px !important; letter-spacing: 0.2px; }

  /* ── hint text ── */
  .input-hint { font-size: 12px; font-weight: 500; color: #3d3a50; letter-spacing: 0.3px; }

  /* ── mode badge ── */
  .mode-badge { font-weight: 700 !important; font-size: 11.5px !important; letter-spacing: 0.4px !important; }

  /* hover states */
  .chip:hover { background: rgba(124,58,237,0.15) !important; border-color: rgba(167,139,250,0.3) !important; color: #c4b5fd !important; }
  .chip-s { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.09); border-radius: 24px; padding: 9px 18px; color: #b0a8cc; font-size: 13px; cursor: pointer; transition: all 0.15s; }
  .chip-s:hover { background: rgba(34,197,94,0.15) !important; border-color: rgba(34,197,94,0.3) !important; color: #4ade80 !important; }
  .chip, .chip-s { font-weight: 600 !important; }
  .quiz-opt:hover { background: rgba(255,255,255,0.09) !important; border-color: rgba(255,255,255,0.2) !important; transform: translateX(3px); }
  .quiz-next:hover { opacity: 0.85; transform: translateX(2px); }
  .conv-item:hover { background: rgba(255,255,255,0.05) !important; color: #ccc !important; }
  .settings-btn:hover { background: rgba(255,255,255,0.05) !important; }
  .new-chat-btn:hover { opacity: 0.85; transform: translateY(-1px); box-shadow: 0 4px 20px rgba(124,58,237,0.3); }
  .send-btn:hover:not(:disabled) { box-shadow: 0 0 20px rgba(124,58,237,0.5); transform: scale(1.05); }
  .input-box:focus-within { border-color: rgba(167,139,250,0.4) !important; box-shadow: 0 0 0 3px rgba(124,58,237,0.08); }
  .auth-input:focus { border-color: rgba(167,139,250,0.5) !important; box-shadow: 0 0 0 3px rgba(124,58,237,0.12); }
  .auth-btn:hover { opacity: 0.9; transform: translateY(-1px); box-shadow: 0 6px 24px rgba(124,58,237,0.35); }
  .danger-btn:hover { background: rgba(239,68,68,0.18) !important; }
  .hamburger:hover span { background: #e2deff !important; }
  .tool-btn:hover { background: rgba(34,197,94,0.18) !important; transform: translateY(-1px); }
  .mode-btn, .mode-btn-s { font-weight: 700 !important; font-size: 12.5px !important; }
  .quiz-letter { font-weight: 800 !important; font-size: 13px !important; }

  @keyframes blink { 0%,80%,100% { opacity:.2; transform:scale(.85); } 40% { opacity:1; transform:scale(1); } }
  .dot-1 { animation: blink 1.2s ease-in-out infinite 0s; }
  .dot-2 { animation: blink 1.2s ease-in-out infinite .2s; }
  .dot-3 { animation: blink 1.2s ease-in-out infinite .4s; }
`;
